var searchData=
[
  ['pivot',['Pivot',['../class_g_x_p_engine_1_1_pivot.html',1,'GXPEngine']]]
];
