var searchData=
[
  ['addchild',['AddChild',['../class_g_x_p_engine_1_1_game_object.html#ad213f53039f4a78d03e1e81d1b00ed55',1,'GXPEngine::GameObject']]],
  ['addchildat',['AddChildAt',['../class_g_x_p_engine_1_1_game_object.html#a407f9f417afaef615fba9852c7c4121d',1,'GXPEngine::GameObject']]],
  ['animationsprite',['AnimationSprite',['../class_g_x_p_engine_1_1_animation_sprite.html#a7aae689ba51de47b88048c56c655bf16',1,'GXPEngine.AnimationSprite.AnimationSprite(string filename, int cols, int rows, int frames=-1)'],['../class_g_x_p_engine_1_1_animation_sprite.html#adb45dabf078ed4b54fe4114dd3310e70',1,'GXPEngine.AnimationSprite.AnimationSprite(System.Drawing.Bitmap bitmap, int cols, int rows, int frames=-1)']]]
];
