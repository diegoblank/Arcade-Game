var searchData=
[
  ['setchildindex',['SetChildIndex',['../class_g_x_p_engine_1_1_game_object.html#aee5eda02a379782f6a1a6034c178fe71',1,'GXPEngine::GameObject']]],
  ['setcolor',['SetColor',['../class_g_x_p_engine_1_1_sprite.html#a1273156710bcf4143a80147a721a696d',1,'GXPEngine::Sprite']]],
  ['setframe',['SetFrame',['../class_g_x_p_engine_1_1_animation_sprite.html#ac1814eb56833aacf3ef62a93ed714fdd',1,'GXPEngine::AnimationSprite']]],
  ['setorigin',['SetOrigin',['../class_g_x_p_engine_1_1_sprite.html#a7f23dfc233b1a22c92ca548a5a6e7efc',1,'GXPEngine::Sprite']]],
  ['setviewport',['SetViewport',['../class_g_x_p_engine_1_1_game.html#afecde817f37c96e76d26593c7fcac853',1,'GXPEngine::Game']]],
  ['showmouse',['ShowMouse',['../class_g_x_p_engine_1_1_game.html#a2f0f1eb7d0ba0c275deaef45421b8544',1,'GXPEngine::Game']]],
  ['sound',['Sound',['../class_g_x_p_engine_1_1_sound.html#a0f1aaede78ecba23937a82ed53272197',1,'GXPEngine::Sound']]],
  ['sound',['Sound',['../class_g_x_p_engine_1_1_sound.html',1,'GXPEngine']]],
  ['soundchannel',['SoundChannel',['../class_g_x_p_engine_1_1_sound_channel.html',1,'GXPEngine']]],
  ['sprite',['Sprite',['../class_g_x_p_engine_1_1_sprite.html#abeb17c5380c00ca3705b2442694ba4a1',1,'GXPEngine.Sprite.Sprite(System.Drawing.Bitmap bitmap)'],['../class_g_x_p_engine_1_1_sprite.html#ab17521fb8104d21a9b609f8c70489317',1,'GXPEngine.Sprite.Sprite(string filename)']]],
  ['sprite',['Sprite',['../class_g_x_p_engine_1_1_sprite.html',1,'GXPEngine']]],
  ['start',['Start',['../class_g_x_p_engine_1_1_game.html#a60cfaccee44dd4badd8629bcd9936beb',1,'GXPEngine::Game']]],
  ['stepdelegate',['StepDelegate',['../class_g_x_p_engine_1_1_game.html#a4d1f2cf034dc8d50480f94ea0da11fb4',1,'GXPEngine::Game']]],
  ['stop',['Stop',['../class_g_x_p_engine_1_1_sound_channel.html#aa398367364ddf786a89587ce1823ad42',1,'GXPEngine::SoundChannel']]]
];
