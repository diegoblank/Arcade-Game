var searchData=
[
  ['texture',['texture',['../class_g_x_p_engine_1_1_sprite.html#a48c7dbc7d4d7903e23e23ee42f934df6',1,'GXPEngine::Sprite']]],
  ['transformpoint',['TransformPoint',['../class_g_x_p_engine_1_1_game_object.html#a749ca5e7b0beb2032a70e4fc38e7382f',1,'GXPEngine::GameObject']]]
];
