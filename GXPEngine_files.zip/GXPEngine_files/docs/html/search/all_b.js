var searchData=
[
  ['removechild',['RemoveChild',['../class_g_x_p_engine_1_1_game_object.html#a6dd2b18321681958c92110b4b6162efc',1,'GXPEngine::GameObject']]],
  ['render',['Render',['../class_g_x_p_engine_1_1_game_object.html#a442d88867c7be365abe6d73f9de7b923',1,'GXPEngine::GameObject']]]
];
