var searchData=
[
  ['game',['Game',['../class_g_x_p_engine_1_1_game.html#a6d10f637740761e26fbe3668649b0680',1,'GXPEngine::Game']]],
  ['gameobject',['GameObject',['../class_g_x_p_engine_1_1_game_object.html#a8257b079399c7e5d31022881557173a7',1,'GXPEngine::GameObject']]],
  ['getchildren',['GetChildren',['../class_g_x_p_engine_1_1_game_object.html#a43e343df6e497131e64f9b755e7093f8',1,'GXPEngine::GameObject']]],
  ['getcollisions',['GetCollisions',['../class_g_x_p_engine_1_1_game_object.html#aa55ad32321703f3226fcc601e7f28823',1,'GXPEngine::GameObject']]],
  ['getextents',['GetExtents',['../class_g_x_p_engine_1_1_sprite.html#a53815903035f9af8f3fbc0f5722c2a82',1,'GXPEngine::Sprite']]]
];
