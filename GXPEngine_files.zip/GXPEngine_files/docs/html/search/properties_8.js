var searchData=
[
  ['texture',['texture',['../class_g_x_p_engine_1_1_sprite.html#a48c7dbc7d4d7903e23e23ee42f934df6',1,'GXPEngine::Sprite']]]
];
