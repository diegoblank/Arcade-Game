﻿using System;
namespace GXPEngine
{
	public class BaseLongCargo : Sprite
	{
		public BaseLongCargo(int PosX, int PosY) : base ("wagonplatform800.png")
		{
			SetXY(PosX, PosY);


		}
	}
}
