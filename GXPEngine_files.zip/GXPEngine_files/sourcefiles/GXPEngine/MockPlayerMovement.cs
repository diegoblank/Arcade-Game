﻿using System;
namespace GXPEngine
{
	public class MockPlayerMovement : GameObject
	{
		public MockPlayerMovement()
		{
		}


		void Update()
		{



		}

	}


}
