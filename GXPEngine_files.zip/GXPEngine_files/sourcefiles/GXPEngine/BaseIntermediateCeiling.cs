﻿using System;
namespace GXPEngine
{
	public class BaseIntermediateCeiling : Sprite
	{
		public BaseIntermediateCeiling(int PosX, int PosY) : base ("baseintermediateceiling.png")
		{
			SetXY(PosX, PosY);
		}
	}
}
