﻿using System;
namespace GXPEngine
{
	public class IntermediateBackground : Sprite
	{
		public IntermediateBackground(int PosX, int PosY) : base ("intermediatebackground.png")
		{
			SetXY(PosX, PosY);
		}
	}
}
