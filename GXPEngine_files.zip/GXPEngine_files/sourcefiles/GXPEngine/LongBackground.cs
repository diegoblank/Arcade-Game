﻿using System;
namespace GXPEngine
{
	public class LongBackground : Sprite
	{
		public LongBackground(int PosX, int PosY) : base("longbackground.png")
		{
			SetXY(PosX, PosY);
		}
	}
}
