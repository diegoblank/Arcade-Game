﻿using System;
namespace GXPEngine
{
	public class LongCeiling : Sprite
	{
		public LongCeiling(int PosX, int PosY): base("baseceiling.png")
		{
			SetXY(PosX, PosY);
		}
	}
}
