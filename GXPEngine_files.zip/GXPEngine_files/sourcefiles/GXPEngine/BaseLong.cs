﻿using System;
namespace GXPEngine
{
	public class BaseLong : Sprite
	{
		public BaseLong(int PosX, int PosY): base ("wagonplatform800.png")
		{
			SetXY(PosX, PosY);
		}
	}
}
