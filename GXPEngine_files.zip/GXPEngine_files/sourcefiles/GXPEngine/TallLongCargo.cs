﻿using System;
namespace GXPEngine
{
	public class TallLongCargo : Sprite
	{
		public TallLongCargo(int PosX, int PosY) : base ("Wagon 800x220.png")
		{

			SetXY(PosX, PosY);

		}
	}
}
