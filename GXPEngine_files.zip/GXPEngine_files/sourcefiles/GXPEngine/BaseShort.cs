﻿using System;
namespace GXPEngine
{
	public class BaseShort : Sprite
	{
		public BaseShort(int PosX, int PosY) : base ("wagonplatform400.png")
		{
			SetXY(PosX, PosY);
		}
	}
}
