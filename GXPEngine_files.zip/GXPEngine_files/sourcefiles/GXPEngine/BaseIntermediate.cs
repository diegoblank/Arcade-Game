﻿using System;
namespace GXPEngine
{
	public class BaseIntermediate : Sprite
	{
		public BaseIntermediate(int PosX, int PosY) : base ("wagonplatform600.png")
		{
			SetXY(PosX, PosY);
		}
	}
}
